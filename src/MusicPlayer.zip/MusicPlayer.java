abstract class MusicPlayer implements Player {
    String status;
    //Song[] songs;

    public MusicPlayer(String status) {
        this.status = status;
    }

}
