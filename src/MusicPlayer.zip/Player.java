public interface Player {
    String play();
    String pause();
    String next();
    String prev();
}
